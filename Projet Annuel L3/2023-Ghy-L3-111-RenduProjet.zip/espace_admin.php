<?php
error_reporting(E_ALL);
session_start();    
//error_reporting(E_ALL);// Activer l'affichage de toutes les erreurs
include("connexionBDD.php"); // utilise la connexion à la base de données  
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Idées de cadeaux</title>
        <link rel="stylesheet" type="text/css" href="CSS/main2.css">
        <link rel="stylesheet" href="CSS/Espace.css">
        <title> Mon espace</title>
    </head>
<body>
    <header role="header">
        <nav class="menu" role="navigation">
                <div class="inner"></div>
            <div class="m-center">
                <h1 class="logo">Mon compte</h1>
            </div>
            <div class="m-left" style="text-align:center;">
                <a href="AccueilUser.html" class="m-link"> Accueil</a>
                <a href="PropoCDO1.php"class="m-link">Suggestion </a>
                <a href="QuestionnaireQ1.php"class="m-link">Questionnaire </a>
            </div>
        </nav>
    </header>
            <div class="container">
                <div class="row">
                  <a href="Deconnexion.php"><div class="square">Se déconnecter</div></a>
                  <a href="Supp_compte.php"><div class="square">Supprimer mon compte</div></a>
                  <a href="ListeUtil.php"><div class="square">Liste utilisateurs</div></a>
                </div>
                <div class="row">
                 <a href="Compte.php"><div class="square">Mon compte</div></a>
                 <a href="Favoris.php"><div class="square">Mes favoris</div></a>
                 <a href="Gestioncdo.php"><div class="square">Outils de gestion</div></a>
                </div>
              </div> 
              <div class="logo1"><img src="C:\Users\Home\Downloads\rechercher.png" width="25px"></div>
              <div class="Barre"><input type="search" placeholder="Anniversaire" ><div style=" position: relative;"></div>  
</body>
</html>