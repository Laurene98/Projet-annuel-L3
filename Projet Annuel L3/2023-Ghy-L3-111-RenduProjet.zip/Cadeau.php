<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Idées de cadeaux</title>
  <link rel="stylesheet" type="text/css" href="Maincss2.css">
    <title>Questionnaire (1/4)</title>


</head>
<body >
  <div class="cloud-container">
  <img class="cloud-image">
  <div class="cloud-text" style="text-align:center; margin: 150px; color: black;">
    <p> Salut! Je voudrais savoir quel est l'âge de la personne qui va recevoir de merveilleux cadeaux !</p>
  </div>
</div>
<input type="range" min="0" max="150" value="75" step="1" id="ageSlider">
<label for="ageSlider"> ge :</label>
</body>
</html>
