<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Idées de cadeaux</title>
  <link rel="stylesheet" href="Main.css">
    <title> Page d'accueil</title>


</head>
<body class="button">
     <div style="text-align:left; margin-left:50px; margin: 150px; color: azure;">
        <h1>Vous ne savez pas quoi offrir ?
        </h1>
        <h1>Vous êtes au bon endroit !</h1>
    </div>
    <div style="text-align:left; margin-left: 50px;margin: 150px; color: #000;">
        <button><a href="Cadeau.php">Je cherche un cadeau</a></button>
    </div>
   
</body class="button">
</html>
